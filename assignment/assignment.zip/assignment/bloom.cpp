#include <skepu>
#include <skepu-lib/io.hpp>

// PNG file IO library
#include "lodepng.h"

// Data structure used for image representation
struct RGBPixel
{
	unsigned char r, g, b;
};



// Image IO boilerplate code, no changes needed
template<typename T>
struct PixelInfo {};

template<>
struct PixelInfo<RGBPixel>
{
	static constexpr LodePNGColorType type = LCT_RGB;
	static constexpr size_t bytes = 3;
};

// Reads a file from png and retuns it as a skepu::Matrix. Uses a library called LodePNG.
template<typename Pixel>
void ReadPngFileToMatrix(skepu::Matrix<Pixel> &inputMatrix, std::string filePath)
{
	skepu::external([&]
	{
		std::vector<unsigned char> image_buf;
		unsigned imageWidth, imageHeight;
		unsigned error = lodepng::decode(image_buf, imageWidth, imageHeight, filePath, PixelInfo<Pixel>::type);
		if (error) SKEPU_ERROR("decoder error " << error << ": " << lodepng_error_text(error));
		inputMatrix.init(imageHeight, imageWidth);
		Pixel *imgView = reinterpret_cast<Pixel*>(image_buf.data());
		std::copy(imgView, imgView + imageHeight * imageWidth, inputMatrix.data());
	}, skepu::write(inputMatrix));
}

template<typename Pixel>
void WritePngFileMatrix(skepu::Matrix<Pixel> &imageData, std::string filePath)
{
	skepu::external(skepu::read(imageData), [&]
	{
		unsigned error = lodepng::encode(filePath, reinterpret_cast<unsigned char*>(imageData.data()), imageData.total_cols(), imageData.total_rows(), PixelInfo<Pixel>::type);
		if (error) SKEPU_ERROR("decoder error " << error << ": " << lodepng_error_text(error));
	});
}
// End of boilerplate code




// User function for generating gaussian filter coefficients
float gauss_weights_kernel(skepu::Index1D index, size_t r, float sigma)
{
	const float pi = 3.141592;
	float i = (float)index.i - r;
	return exp(-i*i / (2 * sigma * sigma)) / (sqrt(2 * pi) * sigma);
}

// User function for image filtering with given weights
RGBPixel convolution_kernel(skepu::Region1D<RGBPixel> in, skepu::Vec<float> filter, float offset, float scaling)
{
	float r = 0;
	float g = 0;
	float b = 0;
	
	for (int i = -in.oi; i <= in.oi; i++)
	{
		RGBPixel p = in(i);
		float coeff = filter(i + in.oi);
		r += p.r * coeff;
		g += p.g * coeff;
		b += p.b * coeff;
	}
	
	RGBPixel result;
	result.r = (r + offset) * scaling;
	result.g = (g + offset) * scaling;
	result.b = (b + offset) * scaling;
	return result;
}



int main(int argc, char *argv[])
{
	// Argument parsing
	if (argc < 4)
	{
	  skepu::io::cout << "Usage: " << argv[0] << " in out radius\n";
	  exit(1);
	}
	
	std::string in{argv[1]};
	std::string out{argv[2]};
	size_t blur_radius = atoi(argv[3]);

	// Data structures and file read
	skepu::Matrix<::RGBPixel> image;
	ReadPngFileToMatrix(image, in);
	skepu::io::cout << "Read image of height: " << image.total_rows() << " and width: " << image.total_cols() << "\n";
	skepu::Matrix<::RGBPixel> temp(image.total_rows(), image.total_cols());
  
	skepu::Vector<float> filter(blur_radius * 2 + 1);
	
	// Skeleton declaration and instantiation
	auto filter_gen = skepu::Map<0>(gauss_weights_kernel);
	auto convolution_rgb = skepu::MapOverlap(convolution_kernel);
	
	// Skeleton invocations (actual computation part)
	filter_gen(filter, blur_radius, sqrt(blur_radius));
	
	convolution_rgb.setOverlap(blur_radius);
	convolution_rgb.setEdgeMode(skepu::Edge::Duplicate);
	
	convolution_rgb.setOverlapMode(skepu::Overlap::RowWise);
	convolution_rgb(temp, image, filter, 0, 1.0);
	convolution_rgb.setOverlapMode(skepu::Overlap::ColWise);
	convolution_rgb(image, temp, filter, 0, 1.0);
	
	// Write file
	WritePngFileMatrix(image, out);
	skepu::io::cout << "Wrote image to file of height: " << image.total_rows() << " and width: " << image.total_cols() << "\n";
	
	return 0;
}